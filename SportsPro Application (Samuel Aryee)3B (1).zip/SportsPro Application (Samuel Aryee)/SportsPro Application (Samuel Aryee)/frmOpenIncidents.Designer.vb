﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOpenIncidents
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lvIncidents = New System.Windows.Forms.ListView()
        Me.colProductCode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDateOpened = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCustomerName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTecchnician = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colTitle = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'lvIncidents
        '
        Me.lvIncidents.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colProductCode, Me.colDateOpened, Me.colCustomerName, Me.colTecchnician, Me.colTitle})
        Me.lvIncidents.HideSelection = False
        Me.lvIncidents.Location = New System.Drawing.Point(12, 31)
        Me.lvIncidents.Name = "lvIncidents"
        Me.lvIncidents.Size = New System.Drawing.Size(884, 392)
        Me.lvIncidents.TabIndex = 0
        Me.lvIncidents.UseCompatibleStateImageBehavior = False
        Me.lvIncidents.View = System.Windows.Forms.View.Details
        '
        'colProductCode
        '
        Me.colProductCode.Text = "Product Code"
        Me.colProductCode.Width = 135
        '
        'colDateOpened
        '
        Me.colDateOpened.Text = "Date Opened"
        Me.colDateOpened.Width = 119
        '
        'colCustomerName
        '
        Me.colCustomerName.Text = "Customer"
        Me.colCustomerName.Width = 108
        '
        'colTecchnician
        '
        Me.colTecchnician.Text = "Technician"
        Me.colTecchnician.Width = 130
        '
        'colTitle
        '
        Me.colTitle.Text = "Title"
        Me.colTitle.Width = 108
        '
        'frmOpenIncidents
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 436)
        Me.Controls.Add(Me.lvIncidents)
        Me.Name = "frmOpenIncidents"
        Me.Text = "Open Incidents"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lvIncidents As ListView
    Friend WithEvents colProductCode As ColumnHeader
    Friend WithEvents colDateOpened As ColumnHeader
    Friend WithEvents colTecchnician As ColumnHeader
    Friend WithEvents colTitle As ColumnHeader
    Public WithEvents colCustomerName As ColumnHeader
End Class
