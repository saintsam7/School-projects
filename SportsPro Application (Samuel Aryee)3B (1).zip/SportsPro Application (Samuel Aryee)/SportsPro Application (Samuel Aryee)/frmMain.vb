﻿Public Class frmMain
    Private Sub MaintainProducts2AToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaintainProducts2AToolStripMenuItem.Click
        frmProductMaintenance.MdiParent = Me
        frmProductMaintenance.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MaintainCustomers2BToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaintainCustomers2BToolStripMenuItem.Click
        frmCustomerMaintenance.MdiParent = Me
        frmCustomerMaintenance.Show()
    End Sub

    Private Sub DIsplayIncidentsByProducts2CToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DIsplayIncidentsByProducts2CToolStripMenuItem.Click
        frmProductIncidents.MdiParent = Me
        frmProductIncidents.Show()
    End Sub

    Private Sub CreateMailingList5CToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CreateMailingList5CToolStripMenuItem.Click

    End Sub

    Private Sub DisplayOpenIncidents3AToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisplayOpenIncidents3AToolStripMenuItem.Click
        frmOpenIncidents.MdiParent = Me
        frmOpenIncidents.Show()
    End Sub

    Private Sub CreateIncident3BToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateIncident3BToolStripMenuItem.Click



        frmCreateIncident.MdiParent = Me
        frmCreateIncident.Show()



    End Sub
End Class
