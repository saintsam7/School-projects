﻿
Imports TechSupportData

Public Class frmCreateIncident
    Private customerList As List(Of Customer)
    Private productList As List(Of Product)

    Private Sub frmCreateIncident_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadComboBoxes()

    End Sub

    Private Sub LoadComboBoxes()
        Try
            customerList = CustomerDB.GetCustomerList
            cboCustomer.DataSource = customerList
            cboCustomer.DisplayMember = "Name"
            cboCustomer.ValueMember = "CustomerID"

            productList = ProductDB.GetProductList
            cboProducts.DataSource = productList
            cboProducts.DisplayMember = "Name"
            cboProducts.ValueMember = "ProductCode"
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType.ToString)
        End Try

    End Sub

    Private Sub cboCustomer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCustomer.SelectedIndexChanged

    End Sub


    Private Sub btnCreateIncident_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateIncident.Click
        Try
            If IsValidData() Then
                Dim customerID = CInt(cboCustomer.SelectedValue)
                Dim productCode As String = cboProducts.SelectedValue

                If RegistrationDB.ProductRegistered(customerID, productCode) Then
                    Dim incident As New Incident
                    With incident
                        incident.CustomerID = CInt(cboCustomer.SelectedValue)
                        incident.ProductCode = CStr(cboProducts.SelectedValue)
                        incident.Title = txtTitle.Text
                        incident.DateOpened = Date.Today.ToShortDateString
                    End With
                    IncidentDB.AddIncident(incident)
                    MessageBox.Show("Has been registered.", "Confirmation Message")
                    Me.Close()
                Else
                    MessageBox.Show("Customer is not registered with the selected product. " & "The data wasn't added.", "Data Error!")
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType.ToString)
        End Try

    End Sub

    Private Function IsValidData() As Boolean
        Return Validator.IsPresent(txtTitle, "Title") And
        Validator.IsPresent(txtDescription, "Description")


    End Function

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Close()
    End Sub
End Class