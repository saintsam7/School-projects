﻿' Name:         Samuel Aryee
' Project title:Maintain Customers
' Date:         March 05, 2018


Imports System.Data.OleDb

Public Class frmCustomerMaintenance
    Private Sub frmCustomerMaintenance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Code to handle any data errors that might occur.
        Try
            'TODO: This line of code loads data into the 'TechSupportDataSet_2B.States' table. You can move, or remove it, as needed.
            Me.StatesTableAdapter.Fill(Me.TechSupportDataSet_2B.States)
            'TODO: This line of code loads data into the 'TechSupportDataSet_2B.Customers' table. You can move, or remove it, as needed.
            Me.CustomersTableAdapter.Fill(Me.TechSupportDataSet_2B.Customers)
        Catch Er As Exception
            MsgBox(Er.Message, Er.GetType.ToString)
        End Try
    End Sub



    Private Sub GetCustomerToolStripButton_Click(sender As Object, e As EventArgs) Handles GetCustomerToolStripButton.Click
        ' Parameterized query that retrieves a customer row based on the customer ID the user enteres.
        Try
            Dim customerID As Integer = Convert.ToInt32(CustomerIDToolStripTextBox.Text)
            Me.CustomersTableAdapter.GetCustomer(Me.TechSupportDataSet_2B.Customers, customerID)
        Catch er As FormatException
            MessageBox.Show("Customer Id must be an integer", "Entry Error")
            CustomerIDToolStripTextBox.Text = ""
        Catch er As System.Exception
            MessageBox.Show(er.Message, er.GetType.ToString)
            CustomerIDToolStripTextBox.Text = ""
        End Try


    End Sub

    ' Event handler that responds to the user clicking on the cancel button
    Private Sub BindingNavigatorCancelItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorCancelItem.Click
        Try
            Me.CustomersBindingSource.CancelEdit()
        Catch er As Exception
            MsgBox(er.Message, er.GetType.ToString)
        End Try
    End Sub

    ' Data validation Code to check that the user enters data into each required colun and wired to the 
    ' CustomersBindingNavigatorSaveItem click event.

    Private Sub CustomersBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomersBindingNavigatorSaveItem.Click

        If IsValidData() Then
            Try
                Me.Validate()
                Me.CustomersBindingSource.EndEdit()
                Me.TableAdapterManager.UpdateAll(Me.TechSupportDataSet_2B)
            Catch er As FormatException
                MessageBox.Show(er.Message, er.GetType.ToString)
                Me.CustomersBindingSource.CancelEdit()
            Catch er As OleDb.OleDbException
                MessageBox.Show(er.Message, er.GetType.ToString)
                Me.CustomersBindingSource.CancelEdit()
            Catch er As Exception
                MessageBox.Show(er.Message, er.GetType.ToString)
                Me.CustomersBindingSource.CancelEdit()
            End Try
        End If
    End Sub

    Private Function IsValidData() As Boolean
        If CustomersBindingSource.Count > 0 Then
            Return IsPresent(CustomerIDTextBox, "Customer ID") AndAlso
            IsPresent(NameTextBox, "Name") AndAlso
            IsPresent(AddressTextBox, "Address") AndAlso
            IsPresent(CityTextBox, "City") AndAlso
            IsPresent(StateNameComboBox, "State") AndAlso
            IsPresent(ZipCodeTextBox, "Zip Code") AndAlso
            IsPresent(EmailTextBox, "E-mail Address") AndAlso
            IsPresent(PhoneTextBox, "Phone Number")
        Else
            Return True
        End If
    End Function

    Private Function IsPresent(ByVal control As Control, ByVal name As String) As Boolean
        If control.GetType.ToString = "System.Windows.Forms.TextBox" Then
            Dim textBox As TextBox = CType(control, TextBox)
            If textBox.Text = " " Then
                MessageBox.Show(name & "is a required field.", "Entry Error")
                textBox.Select()
                Return False
            Else
                Return True
            End If
        ElseIf control.GetType.ToString = "System.Windows.Forms.ComboBox" Then
            Dim comboBox As ComboBox = CType(control, ComboBox)
            If comboBox.SelectedIndex = -1 Then
                MessageBox.Show(name & " is a required field.", "Entry Error")
                comboBox.Select()
                Return False
            Else
                Return True
            End If
        End If
        Return True
    End Function

    Private Sub ZipCodeTextBox_TextChanged(sender As Object, e As EventArgs) Handles ZipCodeTextBox.TextChanged

    End Sub
End Class