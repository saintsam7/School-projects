﻿'Name:      Samuel Aryee
'Project:   TechSupportData
'Date:      04/04/2018
'Instructor:Robert Diselets

Imports TechSupportData

Public Class frmOpenIncidents
    Public TechSupport As TechSupportDataSet

    Private Sub frmOpenIncidents_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim incidentList As List(Of Incident)
        Try
            incidentList = IncidentDB.GetOpenIncidents
            If incidentList.Count > 0 Then
                Dim incident As Incident
                For i As Integer = 0 To incidentList.Count - 1
                    incident = incidentList(i)
                    lvIncidents.Items.Add(incident.ProductCode)

                    lvIncidents.Items(i).SubItems.Add(CDate(incident.DateOpened).ToShortDateString)
                    lvIncidents.Items(i).SubItems.Add(incident.CustomerName)
                    lvIncidents.Items(i).SubItems.Add(incident.TechName)
                    lvIncidents.Items(i).SubItems.Add(incident.Title)
                Next
            Else
                MessageBox.Show("All incidents are closed.", "No Open Incidents")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.GetType.ToString)
        End Try
    End Sub
End Class