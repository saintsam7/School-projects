﻿Partial Class TechSupportDataSet_2C
    Partial Public Class ProductsDataTable
        Private Sub ProductsDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging



        End Sub

    End Class
End Class

Namespace TechSupportDataSet_2CTableAdapters
    Partial Public Class ProductsTableAdapter
    End Class

    Partial Public Class IncidentsTableAdapter
    End Class
End Namespace

Namespace TechSupportDataSet_2CTableAdapters
    Partial Public Class CustomersTableAdapter
    End Class

    Partial Public Class IncidentsTableAdapter
    End Class
End Namespace
