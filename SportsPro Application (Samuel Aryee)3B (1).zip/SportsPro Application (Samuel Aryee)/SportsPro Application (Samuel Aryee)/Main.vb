﻿Module Main
    Public Sub FormatZipCode(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.Value.GetType.ToString = "System.String" Then
            Dim s As String = e.Value.ToString
            If IsNumeric(s) Then
                If s.Length = 9 Then
                    e.Value = s.Substring(0, 5) & "-" &
                        s.Substring(5, 4)
                End If
            End If
        End If

    End Sub

    Private Sub UnformatZipcode(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.Value.GetType.ToString = "System.String" Then
            Dim s As String = e.Value.ToString
            e.Value = s.Replace("-", "")

        End If
    End Sub
End Module
