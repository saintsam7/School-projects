﻿Public Class frmProductMaintenance
    Private Sub ProductsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ProductsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ProductsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TechSupportDataSet)

    End Sub

    Private Sub frmProductMaintenance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TechSupportDataSet.Products' table. You can move, or remove it, as needed.
        Me.ProductsTableAdapter.Fill(Me.TechSupportDataSet.Products)

    End Sub

    Private Sub ProductsDataGridView_DataError(ByVal sender As System.Object,
        ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles ProductsDataGridView.DataError
        Dim row As Integer = e.RowIndex + 1
        Dim errorMessage As String = "A data error occurred." & vbCrLf &
            "Row: " & row & vbCrLf &
            " Error: " & e.Exception.ToString
        MessageBox.Show(errorMessage, "Data Error")

    End Sub

    Private Sub ProductsBindingNavigator_RefreshItems(sender As Object, e As EventArgs) Handles ProductsBindingNavigator.RefreshItems

    End Sub
End Class