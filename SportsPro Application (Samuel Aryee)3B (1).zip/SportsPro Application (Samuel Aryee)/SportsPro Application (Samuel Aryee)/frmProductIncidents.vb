﻿Public Class frmProductIncidents
    Private Sub frmProductIncidents_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TechSupportDataSet_2C.Incidents' table. You can move, or remove it, as needed.
        Me.IncidentsTableAdapter.Fill(Me.TechSupportDataSet_2C.Incidents)
        'TODO: This line of code loads data into the 'TechSupportDataSet_2C.Products' table. You can move, or remove it, as needed.
        Me.ProductsTableAdapter.Fill(Me.TechSupportDataSet_2C.Products)

    End Sub

    Private Sub IncidentsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles IncidentsDataGridView.CellContentClick
        'event handler to get customer id and display customer info in child form
        If e.ColumnIndex = 5 Then
            Dim i As Integer = e.RowIndex
            Dim row As DataGridViewRow = IncidentsDataGridView.Rows(i)
            Dim cell As DataGridViewCell = row.Cells(3)
            Dim customerName As String = cell.Value
            Dim customerForm As New frmCustomer

            customerForm.Tag = customerName
            customerForm.ShowDialog()
        End If


    End Sub


End Class