﻿Public Class frmCustomer

    Private Sub frmCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim c As Binding = ZipCodeTextBox.DataBindings("Text")
        AddHandler c.Format, AddressOf FormatZipCode

        Dim customerName As String = Me.Tag
        Me.CustomersTableAdapter.FillByCustomerName(TechSupportDataSet_2C.Customers, customerName)

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Public Sub FormatZipCode(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.Value.GetType.ToString = "System.String" Then
            Dim s As String = e.Value.ToString
            If IsNumeric(s) Then
                If s.Length = 9 Then
                    e.Value = s.Substring(0, 5) & "-" &
                        s.Substring(5, 4)
                End If
            End If
        End If

    End Sub

    Private Sub UnformatZipcode(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.Value.GetType.ToString = "System.String" Then
            Dim s As String = e.Value.ToString
            e.Value = s.Replace("-", "")

        End If
    End Sub
End Class