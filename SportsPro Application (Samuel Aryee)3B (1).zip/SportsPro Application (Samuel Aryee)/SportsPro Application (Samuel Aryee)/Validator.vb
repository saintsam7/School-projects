﻿Imports System.Data.OleDb

Public Class Validator

    Private Shared m_Title As String = "Entry Error"

    Public Shared Property Title()
        Get
            Return m_Title
        End Get
        Set(ByVal value)
            m_Title = value
        End Set
    End Property



    Public Shared Function IsPresent(ByVal textBox As TextBox, ByVal name As String) As Boolean
        If textBox.Text = "" Then
            MessageBox.Show(textBox.Tag & " is a required field.", Title)
            textBox.Select()
            Return False
        Else
            Return True
        End If
    End Function
    Public Shared Function IsSelected(ByVal comboBox As ComboBox) As Boolean
        If comboBox.SelectedIndex < 0 Then
            MessageBox.Show("You must select a value for " & comboBox.Tag & ".", Title)
            comboBox.Select()
            Return False
        Else
            Return True
        End If
    End Function


End Class
