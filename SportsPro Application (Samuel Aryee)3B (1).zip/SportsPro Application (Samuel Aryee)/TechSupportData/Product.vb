﻿Imports System.Data.OleDb


Public Class Product
    Private m_ProductCode As String
    Private m_Name As String
    Private m_Version As String
    Private m_ReleaseDate As String

    Public Sub New()

    End Sub

    Public Property ProductCode As String
        Get
            Return m_ProductCode
        End Get
        Set(ByVal value As String)
            m_ProductCode = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return m_Name
        End Get
        Set(value As String)
            m_Name = value
        End Set
    End Property
    Public Property Version As String
        Get
            Return m_Version
        End Get
        Set(value As String)
            m_Version = value
        End Set
    End Property
    Public Property ReleasedDate As String
        Get
            Return m_ReleaseDate
        End Get
        Set(value As String)
            m_ReleaseDate = value
        End Set
    End Property
End Class
