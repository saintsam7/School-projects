﻿Imports System.Data.OleDb


Public Class RegistrationDB

    Public Shared Function ProductRegistered(ByVal CustomerID As Integer, ByVal productCode As String) _
            As Boolean


        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim updateStatement As String =
                "SELECT Count(*) FROM Registrations " &
                "WHERE CustomerID = @CustomerID " &
                "And ProductCode = @ProductCode"
        Dim updateCommand As New OleDbCommand(updateStatement, connection)

        updateCommand.Parameters.AddWithValue("@CustomerID", CustomerID)

        updateCommand.Parameters.AddWithValue("@ProductCode", productCode)

        Try

            connection.Open()

            Dim count As Integer = updateCommand.ExecuteScalar

            If count > 0 Then

                Return True

            Else

                Return False

            End If

        Catch ex As OleDbException

            Throw ex

        Finally

            connection.Close()

        End Try
    End Function
End Class
