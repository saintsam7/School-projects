﻿Imports System.Data.OleDb

Public Class CustomerDB
    Public Shared Function GetCustomerName(ByVal customerID As Integer) As String
        Dim name As String
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT Name FROM Customers " &
            "WHERE CustomerID = " & customerID
        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            name = selectCommand.ExecuteScalar.ToString
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return name
    End Function

    Public Shared Function GetCustomerList() As List(Of Customer)
        Dim customerList As New List(Of Customer)
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT CustomerID, Name " &
            "FROM Customers " &
            "ORDER BY Name"

        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            Dim reader As OleDbDataReader = selectCommand.ExecuteReader()
            Dim customer As Customer
            Do While reader.Read
                customer = New Customer
                customer.CustomerID = reader("CustomerID").ToString
                customer.Name = reader("Name").ToString
                customerList.Add(customer)
            Loop
            reader.Close()
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return customerList
    End Function
End Class