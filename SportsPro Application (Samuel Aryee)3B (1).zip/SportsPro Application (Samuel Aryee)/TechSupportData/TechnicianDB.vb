﻿Imports System.Data.OleDb

Public Class TechnicianDB
    Public Shared Function GetTechnicianName(ByVal techID As Integer) As String
        Dim name As String
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT Name FROM Technicians " &
            "WHERE TechID = " & techID
        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            name = selectCommand.ExecuteScalar()
            If IsNothing(name) Then
                name = ""
            Else
                name = name.ToString()
            End If
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return name
    End Function
End Class
