﻿
Imports System.Data.OleDb

Public Class IncidentDB
    Public Shared Function GetOpenIncidents() As List(Of Incident)
        Dim incidentList As New List(Of Incident)
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT CustomerID, ProductCode, TechID, DateOpened, Title " & "FROM Incidents " &
            "WHERE DateClosed IS NULL"
        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            Dim reader As OleDbDataReader = selectCommand.ExecuteReader
            Dim incident As Incident
            Do While reader.Read
                incident = New Incident
                incident.CustomerID = CInt(reader("CustomerID"))
                incident.ProductCode = reader("ProductCode").ToString
                If IsDBNull(reader("TechID")) Then
                    incident.TechID = Nothing
                Else
                    incident.TechID = CInt(reader("TechID"))
                End If
                incident.DateOpened = CDate(reader("DateOpened"))
                incident.Title = reader("Title").ToString
                incidentList.Add(incident)
            Loop
            reader.Close()
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return incidentList
    End Function

    Public Shared Sub AddIncident(ByVal incident As Incident)
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim insertStatement As String =
            "INSERT INTO Incidents " &
            "(CustomerID, ProductCode, DateOpened, Title, Description)" &
            "VALUES(@CustomerID, @ProductCode, @DateOpened, @Title, @Description) "

        Dim insertCommand As New OleDbCommand(insertStatement, connection)
        insertCommand.Parameters.AddWithValue("CustomerID", incident.CustomerID)
        insertCommand.Parameters.AddWithValue("ProductCode", incident.ProductCode)
        insertCommand.Parameters.AddWithValue("DateOpened", DateTime.Today)
        insertCommand.Parameters.AddWithValue("Title", incident.Title)
        insertCommand.Parameters.AddWithValue("Description", incident.Description)

        Try
            connection.Open()
            insertCommand.ExecuteNonQuery()
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()

        End Try


    End Sub



End Class
