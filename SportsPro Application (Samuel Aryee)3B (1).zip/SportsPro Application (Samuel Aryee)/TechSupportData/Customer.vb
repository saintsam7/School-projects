﻿Imports System.Data.OleDb

Public Class Customer
    Private m_CustomerID As Integer
    Private m_Name As String

    Public Sub New()

    End Sub

    Public Property CustomerID() As Integer
        Get
            Return m_CustomerID
        End Get
        Set(ByVal value As Integer)
            m_CustomerID = value
        End Set
    End Property

    Public Property Name() As String
        Get
            Return m_Name
        End Get
        Set(ByVal value As String)
            m_Name = value
        End Set
    End Property

End Class
