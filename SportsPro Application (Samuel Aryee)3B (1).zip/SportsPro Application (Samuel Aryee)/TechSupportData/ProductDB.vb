﻿Imports System.Data.OleDb

Public Class ProductDB

    Public Shared Function GetProductName(ByVal productCode As Integer) As String
        Dim name As String
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
                "SELECT Name FROM Products " &
                "WHERE ProductCode = " & productCode
        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            name = selectCommand.ExecuteScalar.ToString
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return name
    End Function

    Public Shared Function GetProductList() As List(Of Product)
        Dim productList As New List(Of Product)
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT ProductCode, Name " &
            "FROM Products " &
            "ORDER BY Name"

        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            Dim reader As OleDbDataReader = selectCommand.ExecuteReader()
            Dim product As Product
            Do While reader.Read
                product = New Product
                product.ProductCode = reader("ProductCode").ToString
                product.Name = reader("Name").ToString
                productList.Add(product)
            Loop
            reader.Close()
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return productList
    End Function
End Class
