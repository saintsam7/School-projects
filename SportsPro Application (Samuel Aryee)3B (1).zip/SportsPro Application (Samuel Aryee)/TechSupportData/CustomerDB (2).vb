﻿Imports System.Data.OleDb

Public Class CustomerDB
    Public Shared Function GetCustomerName(ByVal customerID As Integer) As String
        Dim name As String
        Dim connection As OleDbConnection = TechSupportDB.GetConnection
        Dim selectStatement As String =
            "SELECT Name FROM Customers " &
            "WHERE CustomerID = " & customerID
        Dim selectCommand As New OleDbCommand(selectStatement, connection)
        Try
            connection.Open()
            name = selectCommand.ExecuteScalar.ToString
        Catch ex As Exception
            Throw ex
        Finally
            connection.Close()
        End Try
        Return name
    End Function
End Class
